def searchName(contacts):
    searchedName = input("Enter name to find: ").strip()

    found = False
    for contact in contacts:
        if searchedName.lower() in contact.name.lower():
            print(contact)
            found = True
    if not found:
        print("Contact not found.")

def searchEmail(contacts):
    searchedEmail = input("Enter email to find: ").strip()

    found = False
    for contact in contacts:
        if searchedEmail.lower() in contact.email.lower():
            print(contact)
            found = True
    if not found:
        print("Contact not found.")

def searchPhone(contacts):
    searchedPhone = input("Enter phone number to find: ").strip()

    found = False
    for contact in contacts:
        if searchedPhone == contact.phoneNumber:
            print(contact)
            found = True
    if not found:
        print("Contact not found.")

def searchID(contacts):
    searchedID = input("Enter contact ID to find: ").strip()

    found = False
    for contact in contacts:
        if searchedID == contact.contactID:
            print(contact)
            found = True
    if not found:
        print("Contact not found.")

def search(contacts):
    print("Search by:")
    print("1. Name")
    print("2. Email")
    print("3. Phone")
    print("4. ID")
    print("5. Back")
    searchChoice = input("Enter choice: ")

    match searchChoice:
        case '1':
            searchName(contacts)
        case '2':
            searchEmail(contacts)
        case '3':
            searchPhone(contacts)
        case '4':
            searchID(contacts)
        case '5':
            return
        case _:
            print("Invalid choice")